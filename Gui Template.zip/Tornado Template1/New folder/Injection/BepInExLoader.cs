﻿using BepInEx;
using Gui.Background;
using Gui.Components;
using HarmonyLib;
using UnityEngine;

namespace Gui.Injection
{
    [BepInPlugin("Gui", "com." + "Gui" + ".org", "V1")]
    public class BepInExLoader : BaseUnityPlugin
    {
        void Awake()
        {
            new Harmony("com." + "Gui" + ".org").PatchAll();
        }
    }

    [HarmonyPatch(typeof(GorillaLocomotion.Player), "FixedUpdate")]
    internal class LoadingPatch
    {
      

        static void Postfix()
        {
            
        }
    }
}

