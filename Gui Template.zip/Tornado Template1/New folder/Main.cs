﻿using BepInEx;
using UnityEngine;
using System.Net;
using System;
using System.Collections.Generic;
using Photon.Pun;
using Gui.Background;
using Gui.Components;

[BepInPlugin("com.noxi.noxisbetterthancoder", "noxiishot", "1.0.0")]
public class noxishotterthancoder : BaseUnityPlugin
{
    private Texture2D _imageTexture;
    private Texture2D _boxTexture;
    private Texture2D _buttonTexture;
    private Texture2D _discordButtonTexture;
    private Rect _imageRect;
    private Rect _boxRect;
    private Rect _discordButtonRect;
    private bool _isDragging;
    private Vector2 _dragOffset;
    private Vector2 _velocity;
    private Vector2 _lastDragPoint;
    private Vector2 _currentDragPoint;

    public float ImageVerticalOffset = -160;
    public float ImageAlpha = 1f;
    public float Gravity = 0.5f;
    public float Friction = 0.95f;
    public float BorderThickness = 50f;
    public float ButtonWidth = 200f;
    public float ButtonHeight = 50f;
    public float ButtonSpacing = 10f;
    public string intab = "Base";
    public string[] tabs = new string[]
    {
        "Base","Room","Tag","Visual", "Networked","Test", ""
    };

    private bool _resetVelocity;
    private float _velocityResetTime;
    private const float VelocityResetDuration = 0.11f;

    private List<ButtonInfo> _buttons;
    private List<ButtonInfo> _Roombuttons;
    private List<ButtonInfo> _Tagbuttons;
    private List<ButtonInfo> _Visualbuttons;
    private List<ButtonInfo> _Networkedbuttons;
    private List<ButtonInfo> _Testbuttons;

    private void Start()
    {
        _imageTexture = LoadImageFromUrl(""); // logo url 
        _buttonTexture = LoadImageFromUrl("https://i.postimg.cc/G2DKW9xM/Screenshot-2024-07-26-162002.png"); // button url

        int boxWidth = 600;
        int boxHeight = 400;
        _boxTexture = CreateGradientTexture(boxWidth, boxHeight, new Color(0, 0, 0, 1), new Color(0.4f, 0.4f, 0.4f, 1f)); // black is the bottom gray is the top
        _boxRect = new Rect(100, 300, boxWidth, boxHeight);

        if (_imageTexture != null)
        {
            float imageWidth = 300;
            float imageHeight = 100;
            _imageRect = new Rect(
                _boxRect.x + 300,
                _boxRect.y,
                imageWidth,
                imageHeight
            );
        }

        _buttons = new List<ButtonInfo>
        {
            new ButtonInfo("Room", "Room button clicked", () => tab(2)),
            new ButtonInfo("Tag", "Room button clicked", () => tab(3)),
            new ButtonInfo("Visual", "Room button clicked", () => tab(4)),
            new ButtonInfo("Networked", "Room button clicked", () => tab(5)),
            new ButtonInfo("Test", "Room button clicked", () => tab(6)),
        };
        _Roombuttons = new List<ButtonInfo>
        {
            new ButtonInfo("Go Back", "Go Back button clicked", () => tab(1)),
            new ButtonInfo("Disconnect", "Disconnect button clicked", () => PhotonNetwork.Disconnect()),
        };
        _Tagbuttons = new List<ButtonInfo>
        {
            new ButtonInfo("Go Back", "Go Back button clicked", () => tab(1)),
        };
        _Visualbuttons = new List<ButtonInfo>
        {
            new ButtonInfo("Go Back", "Go Back button clicked", () => tab(1)),

        };
        _Testbuttons = new List<ButtonInfo>
        {
            new ButtonInfo("Go Back", "Go Back button clicked", () => tab(1)),
        };
        _Networkedbuttons = new List<ButtonInfo>
        {
            new ButtonInfo("Go Back", "Go Back button clicked", () => tab(1)),
        };

        ArrangeButtons();
        ArrangeRoomButtons();
        ArrangeTagButtons();
        ArrangeVisualButtons();
        ArrangeTestButtons();
        ArrangeNetworkedButtons();

        if (_discordButtonTexture != null)
        {
            float discordButtonWidth = 50f;
            float discordButtonHeight = 50f;
            _discordButtonRect = new Rect(
                Screen.width - discordButtonWidth - BorderThickness,
                Screen.height - discordButtonHeight - BorderThickness,
                discordButtonWidth,
                discordButtonHeight
            );
        }
    }

    private void ArrangeButtons()
    {
        float totalHeight = _buttons.Count * ButtonHeight + (_buttons.Count - 1) * ButtonSpacing;
        float initialButtonY = _boxRect.y + (_boxRect.height - totalHeight) / 2;

        for (int i = 0; i < _buttons.Count; i++)
        {
            _buttons[i].Rect = new Rect(
                _boxRect.x + (_boxRect.width - ButtonWidth) / 2,
                initialButtonY + i * (ButtonHeight + ButtonSpacing),
                ButtonWidth,
                ButtonHeight
            );
        }
    }
    private void ArrangeRoomButtons()
    {
        float totalHeight = _Roombuttons.Count * ButtonHeight + (_Roombuttons.Count - 1) * ButtonSpacing;
        float initialButtonY = _boxRect.y + (_boxRect.height - totalHeight) / 2;

        for (int i = 0; i < _Roombuttons.Count; i++)
        {
            _Roombuttons[i].Rect = new Rect(
                _boxRect.x + (_boxRect.width - ButtonWidth) / 2,
                initialButtonY + i * (ButtonHeight + ButtonSpacing),
                ButtonWidth,
                ButtonHeight
            );
        }
    }
    private void ArrangeTagButtons()
    {
        float totalHeight = _Tagbuttons.Count * ButtonHeight + (_Tagbuttons.Count - 1) * ButtonSpacing;
        float initialButtonY = _boxRect.y + (_boxRect.height - totalHeight) / 2;

        for (int i = 0; i < _Tagbuttons.Count; i++)
        {
            _Tagbuttons[i].Rect = new Rect(
                _boxRect.x + (_boxRect.width - ButtonWidth) / 2,
                initialButtonY + i * (ButtonHeight + ButtonSpacing),
                ButtonWidth,
                ButtonHeight
            );
        }
    }
    private void ArrangeVisualButtons()
    {
        float totalHeight = _Visualbuttons.Count * ButtonHeight + (_Visualbuttons.Count - 1) * ButtonSpacing;
        float initialButtonY = _boxRect.y + (_boxRect.height - totalHeight) / 2;

        for (int i = 0; i < _Visualbuttons.Count; i++)
        {
            _Visualbuttons[i].Rect = new Rect(
                _boxRect.x + (_boxRect.width - ButtonWidth) / 2,
                initialButtonY + i * (ButtonHeight + ButtonSpacing),
                ButtonWidth,
                ButtonHeight
            );
        }
    }
    private void ArrangeTestButtons()
    {
        float totalHeight = _Testbuttons.Count * ButtonHeight + (_Testbuttons.Count - 1) * ButtonSpacing;
        float initialButtonY = _boxRect.y + (_boxRect.height - totalHeight) / 2;

        for (int i = 0; i < _Testbuttons.Count; i++)
        {
            _Testbuttons[i].Rect = new Rect(
                _boxRect.x + (_boxRect.width - ButtonWidth) / 2,
                initialButtonY + i * (ButtonHeight + ButtonSpacing),
                ButtonWidth,
                ButtonHeight
            );
        }
    }
    private void ArrangeNetworkedButtons()
    {
        float totalHeight = _Networkedbuttons.Count * ButtonHeight + (_Networkedbuttons.Count - 1) * ButtonSpacing;
        float initialButtonY = _boxRect.y + (_boxRect.height - totalHeight) / 2;

        for (int i = 0; i < _Networkedbuttons.Count; i++)
        {
            _Networkedbuttons[i].Rect = new Rect(
                _boxRect.x + (_boxRect.width - ButtonWidth) / 2,
                initialButtonY + i * (ButtonHeight + ButtonSpacing),
                ButtonWidth,
                ButtonHeight
            );
        }
    }
    private void Update()
    {
        if (!_isDragging)
        {
            _boxRect.position += _velocity * Time.deltaTime;
            _velocity.y += Gravity * Time.deltaTime;
            _velocity *= Friction;

            UpdateRelativePositions();

            if (_velocity.magnitude < 0.1f)
            {
                _velocity = Vector2.zero;
            }

            KeepInBounds(_boxRect);
        }

        if (_resetVelocity)
        {
            if (Time.time >= _velocityResetTime)
            {
                _velocity = Vector2.zero;
                _resetVelocity = false;
            }
        }

        ArrangeButtons();
        ArrangeRoomButtons();
        ArrangeTagButtons();
        ArrangeVisualButtons();
        ArrangeTestButtons();
        ArrangeNetworkedButtons();
        mods();
    }
    private void tab(int t)
    {
        intab = tabs[t - 1];
    }
    private void UpdateRelativePositions()
    {
        if (_imageTexture != null)
        {
            _imageRect.position = new Vector2(
                _boxRect.x + 30f,
                _boxRect.y
            );
        }
    }
    bool mod1 = false;
    bool mod2 = false;
    bool mod3 = false;
    bool mod4 = false;
    bool mod5 = false;
    bool mod6 = false;
    bool mod7 = false;
    bool mod8 = false;
    bool mod9 = false;
    bool mod10 = false;

    public void mods()
    {
        if (mod1 == true)
        {

        }
        if (mod2 == true)
        {

        }
        if (mod3 == true)
        {

        }
        if (mod4 == true)
        {

        }
        if (mod5 == true)
        {

        }
        if (mod6 == true)
        {

        }
        if (mod7 == true)
        {

        }
        if (mod8 == true)
        {

        }
        if (mod9 == true)
        {

        }
        if (mod10 == true)
        {

        }

    }
    private void mod1switch(bool en = false) { if (en) { mod1 = true; } else { mod1 = false; } }
    private void mod2switch(bool en = false) { if (en) { mod2 = true; } else { mod2 = false; } }
    private void mod3switch(bool en = false) { if (en) { mod3 = true; } else { mod3 = false; } }
    private void mod4switch(bool en = false) { if (en) { mod4 = true; } else { mod4 = false; } }
    private void mod5switch(bool en = false) { if (en) { mod5 = true; } else { mod5 = false; } }
    private void mod6switch(bool en = false) { if (en) { mod6 = true; } else { mod6 = false; } }
    private void mod7switch(bool en = false) { if (en) { mod7 = true; } else { mod7 = false; } }
    private void mod8switch(bool en = false) { if (en) { mod8 = true; } else { mod8 = false; } }
    private void mod9switch(bool en = false) { if (en) { mod9 = true; } else { mod9 = false; } }
    private void mod10switch(bool en = false) { if (en) { mod10 = true; } else { mod10 = false; } }

    private void OnGUI()
    {
        DrawRoundedBox(_boxRect, Color.black, 10, 8); // Draw the black border with curved corners and thickness 5
        if (_boxTexture != null)
        {
            GUI.DrawTexture(_boxRect, _boxTexture);
        }

        if (_imageTexture != null)
        {
            Color originalColor = GUI.color;
            GUI.color = new Color(originalColor.r, originalColor.g, originalColor.b, ImageAlpha);
            GUI.DrawTexture(_imageRect, _imageTexture);
            _imageRect.position = _boxRect.position + new Vector2(-17.5f, -250f);
            GUI.color = originalColor;
        }
        if (intab.Contains("Base"))
        {
            foreach (var button in _buttons)
            {
                DrawButton(button);
            }
        }
        else if (intab.Contains("Room"))
        {
            foreach (var button in _Roombuttons)
            {
                DrawButton(button);
            }
        }
        else if (intab.Contains("Tag"))
        {
            foreach (var button in _Tagbuttons)
            {
                DrawButton(button);
            }
        }
        else if (intab.Contains("Visual"))
        {
            foreach (var button in _Visualbuttons)
            {
                DrawButton(button);
            }
        }
        else if (intab.Contains("Test"))
        {
            foreach (var button in _Testbuttons)
            {
                DrawButton(button);
            }
        }
        else if (intab.Contains("Networked"))
        {
            foreach (var button in _Networkedbuttons)
            {
                DrawButton(button);
            }
        }


        if (_discordButtonTexture != null)
        {
            GUI.DrawTexture(_discordButtonRect, _discordButtonTexture);
            Event e = Event.current;
            if (e.type == EventType.MouseDown && _discordButtonRect.Contains(e.mousePosition))
            {
                e.Use();
            }
        }

        HandleDragging();
    }

    private void DrawButton(ButtonInfo button)
    {
        if (_buttonTexture != null)
        {
            Color buttonColor = GUI.color;
            buttonColor.a = 1f;
            GUI.color = buttonColor;

            GUI.DrawTexture(button.Rect, _buttonTexture);

            GUI.color = Color.white;
            GUI.Label(new Rect(button.Rect.x, button.Rect.y, button.Rect.width, button.Rect.height), button.Name, new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.MiddleCenter,
                fontSize = 20,
                fontStyle = FontStyle.Bold
            });

            Event e = Event.current;
            if (e.type == EventType.MouseDown && button.Rect.Contains(e.mousePosition))
            {
                GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(64, false, 0.4f);

                if (button.canbetoggled) { button.istoggled = !button.istoggled; }
                else
                {
                    button.Action.Invoke();
                    e.Use();
                }
            }
            if (button.canbetoggled && button.istoggled)
            {
                GUI.color = new Color(0.3f, 0.3f, 0.3f, 1f);
                GUI.DrawTexture(button.Rect, _buttonTexture);
                button.Action.Invoke();
            }
            else if (button.canbetoggled && !button.istoggled)
            {
                button.DisAction.Invoke();
            }
        }
    }

    private void HandleDragging()
    {
        Event e = Event.current;

        if (e.type == EventType.MouseDown && _boxRect.Contains(e.mousePosition))
        {
            _isDragging = true;
            _dragOffset = e.mousePosition - (Vector2)_boxRect.position;
            _lastDragPoint = e.mousePosition;
            e.Use();
        }
        else if (e.type == EventType.MouseDrag && _isDragging)
        {
            _currentDragPoint = e.mousePosition;
            Vector2 delta = _currentDragPoint - _lastDragPoint;
            _boxRect.position += delta;
            _lastDragPoint = _currentDragPoint;
            _velocity = delta / Time.deltaTime;
            _resetVelocity = true;
            _velocityResetTime = Time.time + VelocityResetDuration;

            UpdateRelativePositions();

            e.Use();
        }
        else if (e.type == EventType.MouseUp)
        {
            _isDragging = false;
            e.Use();
        }
    }

    private void KeepInBounds(Rect rect)
    {
        if (rect.x < BorderThickness)
        {
            rect.x = BorderThickness;
            _velocity.x = 0;
        }

        if (rect.x + rect.width > Screen.width - BorderThickness)
        {
            rect.x = Screen.width - BorderThickness - rect.width;
            _velocity.x = 0;
        }

        if (rect.y < BorderThickness)
        {
            rect.y = BorderThickness;
            _velocity.y = 0;
        }

        if (rect.y + rect.height > Screen.height - BorderThickness)
        {
            rect.y = Screen.height - BorderThickness - rect.height;
            _velocity.y = 0;
        }
    }

    private void DrawRoundedBox(Rect position, Color color, float borderRadius, float borderWidth)
    {
        GUIStyle style = new GUIStyle(GUI.skin.box);
        style.normal.background = MakeTex(2, 2, color);

        // Draw the border with the specified thickness
        Rect outerRect = new Rect(position.x - borderWidth, position.y - borderWidth, position.width + 2 * borderWidth, position.height + 2 * borderWidth);
        GUI.Box(outerRect, GUIContent.none, style);

        // Draw the rounded box
        GL.PushMatrix();
        GL.LoadPixelMatrix();
        Texture2D tex = MakeTex((int)position.width, (int)position.height, color);
        Graphics.DrawTexture(new Rect(position.x, position.y, position.width, position.height), tex);
        GL.PopMatrix();
    }

    private Texture2D MakeTex(int width, int height, Color col)
    {
        Color[] pix = new Color[width * height];
        for (int i = 0; i < pix.Length; i++)
        {
            pix[i] = col;
        }
        Texture2D result = new Texture2D(width, height);
        result.SetPixels(pix);
        result.Apply();
        return result;
    }

    private Texture2D LoadImageFromUrl(string url)
    {
        try
        {
            using (var webClient = new WebClient())
            {
                byte[] imageData = webClient.DownloadData(url);
                Texture2D texture = new Texture2D(2, 2);
                texture.LoadImage(imageData);
                return texture;
            }
        }
        catch (Exception ex)
        {
            Debug.LogError($"Failed to load image from {url}. Exception: {ex}");
            return null;
        }
    }

    private Texture2D CreateGradientTexture(int width, int height, Color topColor, Color bottomColor)
    {
        Texture2D texture = new Texture2D(width, height);
        Color[] colors = new Color[width * height];

        for (int y = 0; y < height; y++)
        {
            Color color = Color.Lerp(topColor, bottomColor, (float)y / height);
            for (int x = 0; x < width; x++)
            {
                colors[y * width + x] = color;
            }
        }

        texture.SetPixels(colors);
        texture.Apply();
        return texture;
    }

    private class ButtonInfo
    {
        public string Name { get; }
        public string LogMessage { get; }
        public Action Action { get; }
        public Action DisAction { get; }
        public Rect Rect { get; set; }
        public bool istoggled = false;
        public bool canbetoggled = false;
        public ButtonInfo(string name, string logMessage, Action action, Action dis = null, bool toggle = false)
        {
            Name = name;
            LogMessage = logMessage;
            Action = action;
            canbetoggled = toggle;
            DisAction = dis;
        }
    }
}
