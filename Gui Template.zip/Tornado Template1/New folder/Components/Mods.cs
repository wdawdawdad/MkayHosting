﻿using ExitGames.Client.Photon;
using Photon.Pun;
using Photon.Realtime;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UIElements;
using UnityEngine.XR;
using static Gui.Background.InputHandler;
using Object = UnityEngine.Object;

namespace Gui.Components
{
    public static class Mods
    {
       //GUI mods here


    }
}
