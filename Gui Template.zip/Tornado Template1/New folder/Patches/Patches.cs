﻿using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace Gui.Patches
{
    public class Patches
    {
        [HarmonyPatch(typeof(GorillaNot), "SendReport", MethodType.Normal)]
        public class NoSendReport : MonoBehaviour
        {
            static bool Prefix(string susReason, string susId, string susNick)
            {
                if (!susReason.Contains("rig"))
                    Notif.SendNotification(susNick + " was reported! Reason: " + susReason + " ID: " + susId, Color.red);
                return false;
            }
        }

        [HarmonyPatch(typeof(GameObject))]
        [HarmonyPatch("CreatePrimitive", 0)]
        internal class ShaderFix : MonoBehaviour
        {
            private static void Postfix(GameObject __result)
            {
                __result.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                __result.GetComponent<Renderer>().material.color = new Color32(255, 128, 0, 128);
            }
        }

        [HarmonyPatch(typeof(GorillaNetworkPublicTestsJoin))]
        [HarmonyPatch("GracePeriod", MethodType.Enumerator)]
        class NoGracePeriod
        {
            public static bool Prefix()
            {
                return false;
            }
        }

        [HarmonyPatch(typeof(GorillaNetworkPublicTestsJoin))]
        [HarmonyPatch("LateUpdate", MethodType.Normal)]
        class NoGracePeriod4
        {
            public static bool Prefix()
            {
                return false;
            }
        }

        [HarmonyPatch(typeof(GorillaNetworkPublicTestJoin2))]
        [HarmonyPatch("GracePeriod", MethodType.Enumerator)]
        class NoGracePeriod3
        {
            public static bool Prefix()
            {
                return false;
            }
        }

        [HarmonyPatch(typeof(GorillaNetworkPublicTestJoin2))]
        [HarmonyPatch("LateUpdate", MethodType.Normal)]
        class NoGracePeriod2
        {
            public static bool Prefix()
            {
                return false;
            }
        }

        [HarmonyPatch(typeof(VRRig), "OnDisable", MethodType.Normal)]
        public class OnDisable : MonoBehaviour
        {
            public static bool Prefix(VRRig __instance)
            {
                return !(__instance == GorillaTagger.Instance.offlineVRRig);
            }
        }
    }
}
